# -*- coding: utf-8 -*-
"""Qss template files

Include qss and qss used variables designed by author.

Copyright (c) 2019 lileilei <hustlei@sina.cn>
"""

# the __init__ file is not needed, it's for setup.py to import data dir
